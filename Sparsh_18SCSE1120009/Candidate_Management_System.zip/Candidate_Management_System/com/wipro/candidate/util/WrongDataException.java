package com.wipro.candidate.util;

public class WrongDataException extends Exception {
		@Override
		public String toString()
		{
			return "Data Incorrect";
		}

}
